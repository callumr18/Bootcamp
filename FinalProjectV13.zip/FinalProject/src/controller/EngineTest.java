package controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EngineTest {

	@Test
	void testEncryption() {
		String output =Engine.encryption("comeonnapoli");
		System.out.println(output);
	}
	@Test
	void testDecryption() {
		String output = Engine.decryption("htrjtssfutqn");
		System.out.println(output);
	}
	@Test
	void printTest() {
		System.out.printf("%s%8s%14s%7s%7s%11s%9s%8s%7s%11s%8s\n", "ID", "Title", "Description", "Date", "Time" ,"Language", "Circle", "Stall", "Type", "Duration", "Price");
	}

}
