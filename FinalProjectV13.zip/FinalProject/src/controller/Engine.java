/**
 * 
 */
package controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import model.Customer;
import util.Connector;
import util.InputReader;

/**
 * @author
 *
 */
public class Engine {
	private static final InputReader input = new InputReader();
	private static final Connector db = new Connector();

	/**
	 * 
	 */
	public Engine() {

	}

	/**
	 * A welcome menu
	 * 
	 * @throws FileNotFoundException
	 */
	private static void welcomeMenu() throws FileNotFoundException {
		Boolean quit = true;
		System.out.println("Welcome to the The Theatre Royal");
		while (quit) {
			System.out.println("Press 1. Login");
			System.out.println("Press 2. Register account");
			System.out.println("Press 0 to quit. ");
			int choice = input.getNumber(" ");
			if (choice == 0) {
				System.out.println("Thanks for using Theatre Royal platform");
				db.close();
				System.exit(1);
			} else if (choice == 1) {
				login();
			} else if (choice == 2) {
				registration();
			} else {
				System.out.println("Wrong input.....try again...!!!");
			}
		}
	}

	/**
	 * a method to proceed for the basket
	 */
	private static void basket() {
		int tickets = input.getNumber("How many tickets do you want to book?");
		for (int i = 0; i < tickets; i++) {
			int pID = input.getNumber("Please enter the ID of the show you'd like to add");
			String seatType = input.getText("Please enter the type of seat you'd like, Circle or stall");
			String isConcession = input.getText("Are you a student or under 16? Yes or No");
			if (seatType.toLowerCase().equals("circle")) {
				seatType = new String("Circle");
				db.addTicket(pID, seatType, isConcession);
			}
			if (seatType.toLowerCase().equals("stall")) {
				seatType = new String("Stall");
				db.addTicket(pID, seatType, isConcession);
			}
		}
	}

	/**
	 * starting menu
	 */
	public static void start() {
		Boolean quit = true;

		while (quit) {
			System.out.println("Menu selection");
			System.out.println("Press 1. List all available events.");
			System.out.println("Press 2. List events by date");
			System.out.println("Press 3. Add a performance to basket ");
			System.out.println("Press 4. Review the basket");
			System.out.println("Press 0 to quit. ");
			int ch = input.getNumber("Enter you choice :");
			if (ch == 1) {
				db.getEvents();
			} else if (ch == 0) {
				System.out.println("Thanks for using Theatre Royal platform");
				db.close();
				System.exit(1);
			} else if (ch == 2) {
				String ask = input.getText("Please provide the date you want to search by (yyyy-mm-dd):");
				db.getEventsByDate(ask);
			} else if (ch == 3) {
				db.getPerformances();
				basket();
			} else if (ch == 4) {
				db.reviewBasket();
				basketOptions();
			} else {
				System.out.println("Wrong input.....try again...!!!");
			}
		}
	}

//
	/**
	 * A method to register to the software
	 */
	private static void registration() {
		String name = input.getText("Please enter your name");
		String surName = input.getText("Enter your surname");
		String email = input.getText("Enter the email address");
		String address = input.getText("Enter your home address");
		String tel = input.getText("Enter your telephone number");
		String card = input.getText("Enter your card number (16 digits)");
		if (card.length() > 16 || card.length() < 16) {
			System.out.println("Card number typed wrong, it must be 1-16 characters");
			start();
		}
		String password = input.getText("Enter your password (16 digits)");
		if (password.length() > 16) {
			System.out.println(" Password typed wrong, it must be 1-16 characters");
			start();
		}
		db.registerCustomer(name, surName, email, address, tel, card, encryption(password));
	}

	/**
	 * a login method
	 * 
	 * @throws FileNotFoundException
	 */
	private static void login() throws FileNotFoundException {
		Scanner sc = new Scanner(new File("customerLogin"));
		String mail = sc.nextLine();
		String psw = sc.nextLine();
//		 String mail = input.getText("Please type in your email address");
//		 String psw = input.getText("Now enter your password (16 digits)");
		if (psw.length() > 16) {
			System.out.println(" Password typed wrong, it must be 1-16 characters");
		}
		db.loginCustomer(mail, encryption(psw));
	}

	/**
	 * encrypt the passwords
	 */
	public static String encryption(String text) {
		char[] values = text.toCharArray();
		for (int i = 0; i < values.length; i++) {
			char letter = values[i];
			letter += 5;
			values[i] = letter;
		}
		return new String(values);
	}

	/**
	 * decryption method
	 */
	public static String decryption(String text) {
		char[] values = text.toCharArray();
		for (int i = 0; i < values.length; i++) {
			char letter = values[i];
			letter -= 5;
			values[i] = letter;
		}
		return new String(values);
	}

	/*
	 * Method that calls a new menu to give the user options when reviewing the
	 * basket calls different methods depending on the users choice
	 */
	public static void basketOptions() {
		Boolean quit = true;
		while (quit) {
			System.out.println("Press 1. Delete from the basket");
			System.out.println("Press 2. Confirm purchase");
			System.out.println("Press 3. Return to Menu");
			System.out.println("Press 0. Quit");
			int choice = input.getNumber(" ");
			if (choice == 0) {
				System.out.println("Thanks for using Theatre Royal platform");
				db.close();
				System.exit(1);
			} else if (choice == 1) {
				int delete = input.getNumber("Please enter the ticket ID you want to delete");
				int pid = input.getNumber("Please enter the performance ID of the ticket you want to delete");
				String s = input.getText("Please enter the seat type of the ticket you want to delete");
				db.deleteTicket(delete, pid, s);
				start();
			} else if (choice == 2) {
				String confirm = input.getText("Please enter yor email to confirm to buy");
				db.confirmPurchase(confirm);
				start();
			} else if (choice == 3) {
				start();
			} else {
				System.out.println("Wrong input.....try again...!!!");
			}
		}
	}

	/**
	 * @param args
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException {
		db.connect();
		welcomeMenu();
		start();

	}
}
