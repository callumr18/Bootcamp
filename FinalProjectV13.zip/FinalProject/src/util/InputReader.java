package util;

import java.util.Scanner;

/**
 * This class will handle the input from the user. We need to be able to get a
 * number and some text aftrer giving a prompt to the user.
 */
public class InputReader {
	// instance variables
	private Scanner scanner;

	/**
	 * Constructor for objects of class InputReader
	 */
	public InputReader() {
		// initialise instance variables
		scanner = new Scanner(System.in); // read from the keyboard
	}

	public Scanner getScanner() {
		return scanner;
	}

	public int getNumber(String prompt) {
		System.out.println(prompt);
		try {
			String s = scanner.nextLine();
			int n = Integer.parseInt(s);
			return n;
		} catch (NumberFormatException e) {
			System.out.print("Incorrect input....!!\n");
			return -1;
		}
	}

	public String getText(String prompt) {
		System.out.println(prompt);
		String value = scanner.nextLine();
		return value;
	}
}