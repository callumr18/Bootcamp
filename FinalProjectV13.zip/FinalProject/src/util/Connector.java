package util;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.sql.*;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import controller.Engine;
import model.Customer;
import model.Event;
import model.Performance;
import model.Ticket;

public class Connector {
	private Connection conn;
	private int customerID = 0;

	public Connector() {
		conn = null;

	}

	/**
	 * A method to connect to the database logged from a text file.
	 */
	public void connect() {
		try {
			Scanner s = new Scanner(new File("logindetails.txt"));
			String uname = s.nextLine().trim();
			String pwd = s.nextLine().trim();
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/BookingSystem", uname, pwd);
		} catch (IOException e) {
			System.out.println("Username/Password error.");
			e.printStackTrace();
			return;
		} catch (SQLException e) {
			System.out.println("Login failed.");
			e.printStackTrace();
			return;
		}

		if (conn != null) {
			System.out.println(" ");
		} else {
			System.out.println("Internet connection failed");
		}
	}

	/**
	 * close the connection
	 */
	public void close() {
		try {
			conn.close();
			// System.out.println("Logged off.");
		} catch (SQLException e) {
			// System.out.println("Still logged in.");
			e.printStackTrace();
		}
	}

	/**
	 * get the performances info
	 */
	public void getPerformances() {
		ArrayList<Event> results = new ArrayList<>();
		ArrayList<Performance> performances = new ArrayList<>();

		try {
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM bookingsystem.list_events;");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int pID = rs.getInt("PerformanceID");
				String title = rs.getString("Title");
				String descr = rs.getString("Description");
				String language = rs.getString("Language");
				int stall = rs.getInt("Stall_seat");
				int circle = rs.getInt("Circle_seat");
				String type = rs.getString("Type");
				String duration = rs.getString("Duration");
				String time = rs.getString("Time");
				Date date = rs.getDate("Date");
				int price = rs.getInt("Price");
				Event event = new Event();
				Performance perf = new Performance();
				event.setEventID(pID);
				event.setTitle(title);
				event.setDescription(descr);
				event.setLanguage(language);
				event.setDuration(duration);
				event.setPrice(price);
				event.setType(type);
				perf.setPerformanceID(pID);
				perf.setCircle_seat(circle);
				perf.setStall_seat(stall);
				perf.setTime(time);
				perf.setDate(date);
				results.add(event);
				performances.add(perf);
			}
			System.out.printf("%s%8s%14s%7s%7s%11s%9s%8s%7s%11s%8s\n", "ID", "Title", "Description", "Date", "Time",
					"Language", "Circle", "Stall", "Type", "Duration", "Price");
			Iterator<Event> i1 = results.iterator();
			Iterator<Performance> i2 = performances.iterator();
			while (i1.hasNext() && i2.hasNext()) {
				Event e = i1.next();
				Performance p = i2.next();
				System.out.println(p.getPerformanceID() + " || " + e.getTitle() + " || " + e.getDescription() + " || "
						+ p.getDate() + " || " + p.getTime() + " || " + e.getLanguage() + " || " + p.getCircle_seat()
						+ " || " + p.getStall_seat() + " || " + e.getType() + " || " + e.getDuration() + " || "
						+ e.getPrice());
			}

		} catch (SQLException e) {
			System.out.println("There are not available shows");
			// e.printStackTrace();
		}
	}

	/**
	 * get events available
	 */
	public void getEvents() {
		ArrayList<Event> results = new ArrayList<>();
		try {
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM bookingsystem.event");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int evID = rs.getInt("EventID");
				String title = rs.getString("Title");
				String descr = rs.getString("Description");
				String language = rs.getString("Language");
				String type = rs.getString("Type");
				String duration = rs.getString("Duration");
				int price = rs.getInt("Price");
				Event event = new Event();
				event.setEventID(evID);
				event.setTitle(title);
				event.setDescription(descr);
				event.setLanguage(language);
				event.setType(type);
				event.setDuration(duration);
				event.setPrice(price);
				results.add(event);
			}
			System.out.printf("%s%13s%19s%16s%12s%16s%13s\n", "ID", "Title", "Description", "Language", "Type",
					"Duration", "Price");
			for (Event e : results) {
				System.out.println(
						e.getEventID() + " || " + e.getTitle() + " || " + e.getDescription() + " || " + e.getLanguage()
								+ " || " + e.getType() + " || " + e.getDuration() + " || " + e.getPrice() + "\n");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * get events by supplying a date
	 * 
	 * @param date
	 */
	public void getEventsByDate(String date) {
		ArrayList<Event> events = new ArrayList<>();
		ArrayList<Performance> perfs = new ArrayList<>();
		PreparedStatement ps;
		ResultSet rs;
		try {
			ps = conn.prepareStatement(
					"SELECT performance.performanceID, event.eventID, event.Title, event.description, performance.date, performance.time FROM event left JOIN performance ON performance.EventID = event.EventID where date = ?");
			ps.setString(1, date);
			rs = ps.executeQuery();

			while (rs.next()) {
				int performanceID = rs.getInt("PerformanceID");
				int eventID = rs.getInt("EventID");
				String event_title = rs.getString("Title");
				String event_descr = rs.getString("Description");
				Date performance_date2 = rs.getDate("Date");
				String performance_time = rs.getString("Time");
				Event event1 = new Event();
				Performance perf = new Performance();
				event1.setEventID(eventID);
				perf.setPerformanceID(performanceID);
				event1.setTitle(event_title);
				event1.setDescription(event_descr);
				perf.setDate(performance_date2);
				perf.setTime(performance_time);
				perfs.add(perf);
				events.add(event1);
			}
			System.out.printf("%s%13s%11s%17s%10s%10s\n", "PerformanceID", "EventID", "Title", "Description", "Date",
					"Time");
			Iterator<Event> i1 = events.iterator();
			Iterator<Performance> i2 = perfs.iterator();
			while (i1.hasNext() && i2.hasNext()) {
				Event e = i1.next();
				Performance p = i2.next();
				System.out.println(p.getPerformanceID() + " || " + e.getEventID() + " || " + e.getTitle() + " || "
						+ e.getDescription() + " || " + p.getDate() + " || " + p.getTime());
			}
			if (!rs.next()) {
				System.out.println("Date not found....!!!");
			}

		} catch (SQLException e) {
			System.out.println("Wrong input....!!!");
		}

	}

	/**
	 * a method to add the ticket in a basket
	 * 
	 * @param pID
	 * @param cID
	 * @param seatType
	 * @param isConcession
	 */

	public void addTicket(int pID,String seatType, String isConcession) {
		String date = null;
		String time = null;
		int circle = 0;
		int stall = 0;
		int eID = 0;
		double price = 0;
		ArrayList<Ticket> tickets = new ArrayList<>();
		PreparedStatement ps;
		ResultSet rs;
		CallableStatement myStmt;
		byte isCon2 = 0;

		if (isConcession.toLowerCase().equals("yes")) {
			isCon2 = 1;
		} else if (isConcession.toLowerCase().equals("no")) {
			isCon2 = 0;
		}
		try {
			ps = conn.prepareStatement(
					"select * from  performance left join event on performance.EventID = event.EventID where performanceID = ?;");
			ps.setInt(1, pID);
			rs = ps.executeQuery();
			while (rs.next()) {
				date = rs.getString("Date");
				time = rs.getString("Time");
				circle = rs.getInt("Circle_seat");
				stall = rs.getInt("Stall_seat");
				eID = rs.getInt("EventID");
				price = rs.getDouble("Price");
			}

			System.out.println(pID);
			myStmt = conn.prepareCall("{call bookingsystem.addTicket(?, ?, ?, ? , ?, ?)}");
			myStmt.setInt(1, pID);			
			myStmt.setString(2, date);
			myStmt.setString(3, time);
			myStmt.setDouble(4, price);
			myStmt.setString(5, seatType);
			myStmt.setByte(6, isCon2);
			myStmt.executeUpdate();

			ps = conn.prepareStatement("select * from bookingsystem.ticket");
			rs = ps.executeQuery();
			while (rs.next()) {
				int ticketNum = rs.getInt("TicketID");
				int perfID = rs.getInt("PerformanceID");
				String d = rs.getString("Date");
				String t = rs.getString("Time");
				Double p = rs.getDouble("Price");
				String ty = rs.getString("Seat_Type");
				int under = rs.getByte("Concessionary");
				Ticket ticket = new Ticket();
				ticket.setTicketID(ticketNum);
				ticket.setPerformanceID(perfID);
				ticket.setDate(d);
				ticket.setTime(t);
				ticket.setPrice(p);
				ticket.setSeat_Type(ty);
				ticket.setConcessionary(under);
				tickets.add(ticket);
			}
			System.out.println("Ticket added to basket!!\n");
			System.out.printf("%s%18s%9s%9s%10s%14s%13s\n", "TicketID", "PerformanceID", // 13
					"Date", // 4
					"Time", // 4
					"Price", // 5
					"Seat Type", // 9
					"Under 18"); // 8
			for(Ticket t : tickets) {
			System.out.println(t.getTicketID() + " || " + t.getPerformanceID() + " || "
					+  t.getDate() + " || " + t.getTime() + " || "
					+ t.getPrice() + " || " + t.getSeat_Type() + " || " + t.getConcessionary() + "\n");
			}
		} catch (SQLException e) {
			System.out.println("Ticket was not added to the basket!");
			e.printStackTrace();
		}
	}

	/**
	 * A method to register a customer
	 * 
	 * @param name
	 * @param surn
	 * @param mail
	 * @param addr
	 * @param tel
	 * @param card
	 * @param psw
	 */
	public void registerCustomer(String name, String surn, String mail, String addr, String tel, String card,
			String psw) {
		PreparedStatement procedure;
		ResultSet rs;
		Customer customer = new Customer();

		try {
			procedure = conn.prepareStatement(
					"insert into customer(F_Name, L_Name, Email, Address, Telephone, CreditCard, Password)\r\n"
							+ "values(? ,? ,? ,? ,? ,? ,?);");
			procedure.setString(1, name);
			procedure.setString(2, surn);
			procedure.setString(3, mail);
			procedure.setString(4, addr);
			procedure.setString(5, tel);
			procedure.setString(6, card);
			procedure.setString(7, psw);
			int rowsAffected = procedure.executeUpdate();
			if (rowsAffected > 0) {
				System.out.println("Registration succeeded!");

			} else {
				System.out.println("The registration not succeeded");
			}

			procedure = conn.prepareStatement("select customerId, email from customer where email = ?;");
			procedure.setString(1, mail);
			rs = procedure.executeQuery();
		} catch (SQLException e) {
			System.out.println("Wrong input....!!!");

		}
	}
	/**
	 * A method to login
	 */
	public void loginCustomer(String email, String psw) {
		PreparedStatement ps;
		ResultSet rs1;
		Customer c = new Customer();
		try {
			ps = conn.prepareStatement("SELECT * FROM bookingsystem.login_details where email = ? and password = ?;");
			ps.setString(1, email);
			ps.setString(2, psw);
			rs1 = ps.executeQuery();
			while (rs1.next()) {
				String mail = rs1.getString("Email");
				String passw = rs1.getString("Password");
				c.setEmail(mail);
				c.setPassword(passw);
			}
			if (email.equals(c.getEmail()) && psw.equals(c.getPassword())) {
				System.out.println("Logged in!");
				Engine.start();
			} else {
				System.out.println("Password or/and email not found or wrong!");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*
	 * Method to delete ticket in a basket
	 * 
	 * @param delete - is the ticketID the customer inputs. the Ticket they want to
	 * delete
	 * 
	 * @param pid is the performanceID of the ticket being deteled
	 * 
	 * @param s is the Seat type the ticket had.
	 */
	public void deleteTicket(int delete, int pid, String s) {
		ArrayList<Ticket> basket = new ArrayList<>();
		PreparedStatement ps;
		ResultSet rs;
		CallableStatement myStmt;
		try {
			ps = conn.prepareStatement("select * from bookingsystem.ticket"); // this is the part that retrieves the
																				// data from sql
			rs = ps.executeQuery();
			while (rs.next()) { // checking that there is a next row in the table
				int ticketNum = rs.getInt("TicketID"); // creating local variables to hold the column information of //
														// each row
				int perfID = rs.getInt("PerformanceID");
				String d = rs.getString("Date");
				String t = rs.getString("Time");
				Double p = rs.getDouble("Price");
				String ty = rs.getString("Seat_Type");
				int under = rs.getByte("Concessionary");
				Ticket ticket = new Ticket();
				ticket.setTicketID(ticketNum); // this then uses the local variables to allow the ticket object to store
												// // the column information.
				ticket.setPerformanceID(perfID);
				ticket.setDate(d);
				ticket.setTime(t);
				ticket.setPrice(p);
				ticket.setSeat_Type(ty);
				ticket.setConcessionary(under);
				basket.add(ticket);
			}
			Iterator<Ticket> tick = basket.iterator();
			myStmt = conn.prepareCall("{call bookingsystem.removeTicket(?,?,?)}"); // this removes the row containing
																					// that contains the same TicketID
																					// as the TicketID input
			while (tick.hasNext()) {
				Ticket t = tick.next();
				if (t.getTicketID() == delete) {
					myStmt.setInt(1, delete);
					myStmt.setInt(2, pid);
					myStmt.setString(3, s);
					myStmt.executeUpdate();
					tick.remove();
					System.out.println("Ticket removed");
				}
			}

		} catch (SQLException e) {
			System.out.println("Ticket was not added to the basket!");
			e.printStackTrace();
		}
	}

	/*
	 * Takes all the tickets on the system and displays them for the user to see, it
	 * also displays the total cost of the basket.
	 */
	public void reviewBasket() {
		PreparedStatement ps;
		ResultSet rs;

		ArrayList<Ticket> basket = new ArrayList();
		try {
			ps = conn.prepareStatement("select * from bookingsystem.ticket"); // this is the part that retrieves the
																				// data from sql
			rs = ps.executeQuery();
			while (rs.next()) { // checking that there is a next row in the table
				int ticketNum = rs.getInt("TicketID"); // creating local variables to hold the column information of
														// each row
				int perfID = rs.getInt("PerformanceID");
				String d = rs.getString("Date");
				String t = rs.getString("Time");
				Double p = rs.getDouble("Price");
				String ty = rs.getString("Seat_Type");
				int under = rs.getByte("Concessionary");
				Ticket ticket = new Ticket();
				ticket.setTicketID(ticketNum); // this then uses the local variables to allow the ticket object to store
												// the column information.
				ticket.setPerformanceID(perfID);
				ticket.setDate(d);
				ticket.setTime(t);
				ticket.setPrice(p);
				ticket.setSeat_Type(ty);
				ticket.setConcessionary(under);
				basket.add(ticket);
			}
			if (basket.isEmpty()) {
				System.out.println("The basket is empty, add first to the basket");
				Engine.start();
			}

			System.out.printf("%s%18s%9s%9s%10s%14s%13s\n", "TicketID", "PerformanceID", // 13
					"Date", // 4
					"Time", // 4
					"Price", // 5
					"Seat Type", // 9
					"Under 18"); // 8
			double total_Cost = 0;
			for (Ticket t : basket) { // for each ticket object in the basket list, print the column information.
				System.out.println(t.getTicketID() + " || " + t.getPerformanceID() + " || " + t.getDate() + " || " + t.getTime() + " || " + t.getPrice() + " || " + t.getSeat_Type()
						+ " || " + t.getConcessionary() + "\n");
				total_Cost += t.getPrice(); // totals all the prices of each ticket to display later
			}

			System.out.println("Total Cost is: �" + total_Cost); // prints the total cost of all tickets.
		} catch (SQLException e) {
			System.out.println("Ticket was not added to the basket!");
			e.printStackTrace();
		}
	}

	/*
	 * Method to compare an input card Number to the one stored by the user,
	 * 
	 * @param the customer ID of the user
	 * 
	 * @param creditCard the card Number input by the user to be compared to the one
	 * in the database
	 */
	public void confirmPurchase(String mail) {
		CallableStatement cl;
		PreparedStatement ps;
		ResultSet rs;
		Customer c = new Customer();
		Ticket ticket = new Ticket();
		try {
			ps = conn.prepareStatement("SELECT * FROM bookingsystem.card_details where email = ?;");
			ps.setString(1, mail);
			rs = ps.executeQuery();
			while (rs.next()) {
				String cardNum = rs.getString("creditCard");
				c.setCardNumber(cardNum);
			}
			if (c.getCardNumber() == null) {
				InputReader input = new InputReader();
				String cardNumber = input
						.getText("You haven`t inserted card number when registered, please insert now (16 digits)");
				if (cardNumber.length() > 16 || cardNumber.length() < 16) {
					System.out.println("Card number typed wrong, it must be 1-16 characters");
					return;
				}
				ps = conn.prepareStatement("update card_details set creditcard = ? where email = ?;");
				ps.setString(1, cardNumber);
				ps.setString(2, mail);
				int rows = ps.executeUpdate();
				ps = conn.prepareStatement("select ticketid, performanceid, seat_type from ticket");
				rs = ps.executeQuery();
				while (rs.next()) {
					int tID = rs.getInt("TicketID");
					ticket.setTicketID(tID);
					cl = conn.prepareCall("{call bookingsystem.removeBasket(?)}");
					cl.setInt(1, ticket.getTicketID());
					cl.executeUpdate();
				}
				if (rows > 0) {
					System.out.println("Purchase was successful, thank you!");
					Engine.start();
				} else {
					System.out.println("Something went wrong , try again!");
					Engine.basketOptions();
				}
			} else {
				System.out.println("Thanks for your purchase");
				ps = conn.prepareStatement("select ticketid, performanceid, seat_type from ticket");
				rs = ps.executeQuery();
				while (rs.next()) {
					int tID = rs.getInt("TicketID");
					ticket.setTicketID(tID);
					cl = conn.prepareCall("{call bookingsystem.removeBasket(?)}");
					cl.setInt(1, ticket.getTicketID());
					cl.executeUpdate();
				}
			}
		} catch (SQLException e) {
			System.out.println("Purchase failed, ID or/and credit card number wrong or not found!!");
		}
	}

	/**
	 * @return the customerID
	 */
	public int getCustomerID() {
		return customerID;
	}

	/**
	 * @param customerID the customerID to set
	 */
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
}