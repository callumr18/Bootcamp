package model;

public class Ticket {
	private int ticketID;
	private int performanceID;
	private int customerID;
	private String date;
	private String time;
	private double price;
	private String seat_Type;
	private int concessionary;
	
	
	/**
	 * @return the ticketID
	 */
	public int getTicketID() {
		return ticketID;
	}
	/**
	 * @param ticketID the ticketID to set
	 */
	public void setTicketID(int ticketID) {
		this.ticketID = ticketID;
	}
	/**
	 * @return the performanceID
	 */
	public int getPerformanceID() {
		return performanceID;
	}
	/**
	 * @param performanceID the performanceID to set
	 */
	public void setPerformanceID(int performanceID) {
		this.performanceID = performanceID;
	}
	/**
	 * @return the customerID
	 */
	public int getCustomerID() {
		return customerID;
	}
	/**
	 * @param customerID the customerID to set
	 */
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}
	/**
	 * @return the time
	 */
	public String getTime() {
		return time;
	}
	/**
	 * @param time the time to set
	 */
	public void setTime(String time) {
		this.time = time;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @return the seat_Type
	 */
	public String getSeat_Type() {
		return seat_Type;
	}
	/**
	 * @param seat_Type the seat_Type to set
	 */
	public void setSeat_Type(String seat_Type) {
		this.seat_Type = seat_Type;
	}
	/**
	 * @return the concessionary
	 */
	public String getConcessionary() {
		String y = "";
		if(concessionary == 1) {
			y = "YES";
		}else {y = "NOT";}
		return y;
	}
	/**
	 * @param concessionary the concessionary to set
	 */
	public void setConcessionary(int concessionary) {
		this.concessionary = concessionary;
	}
	
}
