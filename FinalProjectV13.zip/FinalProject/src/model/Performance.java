/**
 * 
 */
package model;

import java.util.Date;

/**
 * @author FinalProject group
 *
 */
public class Performance {
	private int performanceID;
	private int eventID;
	private Date date;
	private String time;
	private int circle_seat;
	private int stall_seat;
	

	/**
	 * a class representing a performance
	 */
	public Performance() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the performanceID
	 */
	public int getPerformanceID() {
		return performanceID;
	}
	/**
	 * @param performanceID the performanceID to set
	 */
	public void setPerformanceID(int performanceID) {
		this.performanceID = performanceID;
	}

	/**
	 * @return the eventID
	 */
	public int getEventID() {
		return eventID;
	}

	/**
	 * @param eventID the eventID to set
	 */
	public void setEventID(int eventID) {
		this.eventID = eventID;
	}

	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * @param d the date to set
	 */
	public void setDate(Date d) {
		this.date = d;
	}

	/**
	 * @return the time
	 */
	public String getTime() {
		return time;
	}

	/**
	 * @param time the time to set
	 */
	public void setTime(String time) {
		this.time = time;
	}

	/**
	 * @return the circle_seat
	 */
	public int getCircle_seat() {
		return circle_seat;
	}

	/**
	 * @param circle_seat the circle_seat to set
	 */
	public void setCircle_seat(int circle_seat) {
		this.circle_seat = circle_seat;
	}

	/**
	 * @return the stall_seat
	 */
	public int getStall_seat() {
		return stall_seat;
	}

	/**
	 * @param stall_seat the stall_seat to set
	 */
	public void setStall_seat(int stall_seat) {
		this.stall_seat = stall_seat;
	}
}
