/**
 * 
 */
package model;



/**
 * @author FinalProject group
 *
 */
public class Customer {
	private int customerID;
	private String F_Name;
	private String L_Name;
	private String email;
	private String address;
	private String telephone;
	private String cardNumber;
	private String password;

	/**
	 * a class representing the customer
	 */
	public Customer() {
		
	}

	
	/**
	 * @return the customerID
	 */
	public int getCustomerID() {
		return customerID;
	}

	/**
	 * @return the f_Name
	 */
	public String getF_Name() {
		return F_Name;
	}

	/**
	 * @param f_Name the f_Name to set
	 */
	public void setF_Name(String f_Name) {
		F_Name = f_Name;
	}

	/**
	 * @return the l_Name
	 */
	public String getL_Name() {
		return L_Name;
	}

	/**
	 * @param l_Name the l_Name to set
	 */
	public void setL_Name(String l_Name) {
		L_Name = l_Name;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the telephone
	 */
	public String getTelephone() {
		return telephone;
	}

	/**
	 * @param telephone the telephone to set
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/**
	 * @return the cardNumber
	 */
	public String getCardNumber() {
		return cardNumber;
	}

	/**
	 * @param cardNumber the cardNumber to set
	 */
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}


	/**
	 * @param customerID the customerID to set
	 */
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

}
